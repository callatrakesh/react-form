import React, { useState, useEffect } from 'react';

    const Profile = () => {

    const [profiles,setProfiles] = useState([]);
    const [formData, setFormData] = useState({
        name:'', 
        email:'', 
        mobileNumber:'', 
        dob:'', 
        qualification:'', 
        address: '', 
        city: '', 
        country: '', 
        zipcode:'', 
        bio: '',  
        profilePhoto: null 
    });
    const [isEditing, setIsEditing] = useState(false);
    const [isVisible, setIsVisible] = useState(false);

    const handleInputChange = (e) => {
        setFormData({
          ...formData,
          [e.target.name]: e.target.value,
        });
    };
   
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        const allowedFileTypes = ['image/jpeg', 'image/png', 'image/gif','image/svg+xml', 'image/bmp','image/webp', 'image/x-icon','image/tiff']; // Allowed MIME types     
        const maxFileSize = 2 * 1024 * 1024; // 2MB size limit (in bytes)
  
        if (file) {
          if (!allowedFileTypes.includes(file.type)) {
            alert('Invalid file type. Only PDF or Word documents are allowed.');
            e.target.value = ''; 
            return;
          }
          if (file.size > maxFileSize) {
            alert('File size exceeds the limit of 2MB.');
            e.target.value = ''; 
            return;
          }
          setFormData({
            ...formData,
            profilePhoto: e.target.files[0],
          });
        }      
    };
    const fetchProfile = (e) => {
        fetch('http://localhost:5000/profiles')
        .then(response => response.json())
        .then(data => setProfiles(data));
    };

    useEffect(() => {
        if (profiles.length > 0) {
          setIsVisible(true);
        } else {
          setIsVisible(false);
        }
      }, [profiles]);
  
      useEffect(() => {
        fetchProfile();                     
}, []);

const handleAddProfile = (e) => {
    e.preventDefault();  // Prevent form submission refresh
    const formDataToSend = new FormData();
    // Append fields to FormData object
    formDataToSend.append('name', formData.name);
    formDataToSend.append('email', formData.email);
    formDataToSend.append('mobileNumber', formData.mobileNumber);
    formDataToSend.append('dob', formData.dob);
    formDataToSend.append('qualification', formData.qualification);
    formDataToSend.append('address', formData.address);
    formDataToSend.append('city', formData.city);
    formDataToSend.append('country', formData.country);
    formDataToSend.append('zipcode', formData.zipcode);
    formDataToSend.append('bio', formData.bio);

    // Append the profile photo file if exists
    if (formData.profilePhoto) {
        formDataToSend.append('profilePhoto', formData.profilePhoto);
    }

    fetch('http://localhost:5000/profiles', {
        method: 'POST',
        body: formDataToSend,
    })
    .then(response => response.json())
    .then(() => {
        fetchProfile();
        setFormData({
            name:'', 
            email:'', 
            mobileNumber:'', 
            dob:'', 
            qualification:'', 
            address: '', 
            city: '', 
            country: '', 
            zipcode:'', 
            bio: '',  
            profilePhoto: null
        });
        setIsEditing(false);
    });
};

const handleUpdateProfile = (e) => {
    e.preventDefault();  // Prevent form submission refresh
    const formDataToSend = new FormData();

    // Append updated fields to FormData object
    formDataToSend.append('name', formData.name);
    formDataToSend.append('email', formData.email);
    formDataToSend.append('mobileNumber', formData.mobileNumber);
    formDataToSend.append('dob', formData.dob);
    formDataToSend.append('qualification', formData.qualification);
    formDataToSend.append('address', formData.address);
    formDataToSend.append('city', formData.city);
    formDataToSend.append('country', formData.country);
    formDataToSend.append('zipcode', formData.zipcode);
    formDataToSend.append('bio', formData.bio);

    // Append the profile photo file if exists
    if (formData.profilePhoto) {
        formDataToSend.append('profilePhoto', formData.profilePhoto);
    }

    fetch(`http://localhost:5000/profiles/${formData.id}`, {
        method: 'PUT',
        body: formDataToSend,
    })
    .then(response => response.json())
    .then(() => {
        fetchProfile();
        setFormData({
            name:'', 
            email:'', 
            mobileNumber:'', 
            dob:'', 
            qualification:'', 
            address: '', 
            city: '', 
            country: '', 
            zipcode:'', 
            bio: '',  
            profilePhoto: null
        });
        setIsEditing(false);
    });
};
const handleDeleteProfile = (id) => {
    fetch(`http://localhost:5000/profiles/${id}`, {
        method: 'DELETE'
    })
    .then(() => {
        fetchProfile();
    });
};

const handleEditProfile = (profiles) => {
    setIsEditing(true);
    setFormData(profiles);
};

const handleResetForm = () => {
    setFormData({
        name:'', 
        email:'', 
        mobileNumber:'', 
        dob:'', 
        qualification:'', 
        address: '', 
        city: '', 
        country: '', 
        zipcode:'', 
        bio: '',  
        profilePhoto: null
    });
    setIsEditing(false);
};

    return(
        <>
           <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-title">{isEditing ? 'Change Your Profile' : 'Create Your Profile'}</h3>
                </div>
                <div className="panel-body">
                    <form action="/profiles" method="post" encType="multipart/form-data">
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label className="form-label">Full Name <span className="required">*</span></label>
                                    <input type="text" className="form-control" name="name" placeholder="What is your name?" value={formData.name} onChange={handleInputChange} required/>
                                </div>
                            </div>    
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">Email ID <span className="required">*</span></label>
                                    <input type="email" className="form-control" name="email" placeholder="Tell us your Email ID" value={formData.email} onChange={handleInputChange} required/>
                                </div>
                            </div> 
                        
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">Mobile Number <span className="required">*</span></label>
                                    <input type="tel" className="form-control" name="mobileNumber" placeholder="Enter your mobile number" value={formData.mobileNumber} onChange={handleInputChange} required/>
                                </div> 
                            </div>
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">Date of Birth <span className="required">*</span></label>
                                    <input type="date" className="form-control" name="dob" placeholder="Your Date of birth" value={formData.dob} onChange={handleInputChange} />
                                </div> 
                            </div>
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">Qualification </label>
                                    <select className='form-control' name='qualification' value={formData.qualification} onChange={handleInputChange}>
                                        <option value="">Select</option>
                                        <option value="Literate">Literate</option>
                                        <option value="Seconday School">Seconday School</option>
                                        <option value="Undergraduate">Undergraduate</option>
                                        <option value="Graduate">Graduate</option>
                                        <option value="Post Graduate">Post Graduate</option>                                    
                                    </select>
                                </div> 
                            </div>
                            <div className="col-md-6">      
                                <div className="form-group">
                                    <label className="form-label">Address <span className="required">*</span></label>
                                    <input type="text" className="form-control" name="address" placeholder="Your Address" value={formData.address} onChange={handleInputChange} />
                                </div> 
                            </div>
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">City <span className="required">*</span></label>
                                    <input type="text" className="form-control" name="city" placeholder="City Name" value={formData.city} onChange={handleInputChange} />
                                </div>  
                            </div>
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">Country <span className="required">*</span></label>
                                    <input type="text" className="form-control" name="country" placeholder="Country Name" value={formData.country} onChange={handleInputChange} />
                                </div> 
                            </div> 
                            <div className="col-md-6">   
                                <div className="form-group">
                                    <label className="form-label">Zip Code <span className="required">*</span></label>
                                    <input type="text" className="form-control" name="zipcode" placeholder=" Your city pin code" value={formData.zipcode} onChange={handleInputChange} />
                                </div>  
                            </div>
                            <div className="col-md-6">  
                                <div className="form-group">
                                    <label className="form-label">Profile Picture</label>
                                    <input type="file" className="form-control" accept=".jpg,.jpeg,.png,.svg" name="profilePhoto" onChange={handleFileChange}/>
                                </div> 
                            </div>
                            <div className="col-md-12">  
                                <div className="form-group">
                                    <label className="form-label">About your self</label>
                                    <textarea className="form-control" rows={5} name='bio' placeholder="Describe about your self" value={formData.bio} onChange={handleInputChange}></textarea>
                                </div>  
                            </div>
                        </div> 
                        {!isEditing ? (
                            <button type="submit" className="btn btn-primary mr10" onClick={handleAddProfile}>Create Profile</button>
                            
                        ) : (
                            <button type="button" className="btn btn-primary mr10" onClick={handleUpdateProfile}>Update Profile</button>
                        )}                         
                        
                        <button type="reset" className="btn" onClick={() => handleResetForm()}>Cancel</button>
                    </form>
                </div>
           </div>
           {isVisible && (
            <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-list">Profile List</h3>
                </div>
                <div className="panel-body">
                    <div className="profile-list">
                        {profiles.map(Profile => (
                            <div key={Profile.id} className="profile-item">
                                <ul className="row">
                                    <li className="col-md-6">
                                        <span className="profile-label">Name</span>
                                        <span className="profile-value">{Profile.name}</span>
                                    </li>
                                    <li className="col-md-6">
                                        <span className="profile-label">Email ID</span>
                                        <span className="profile-value">{Profile.email}</span>
                                    </li>
                                    <li className="col-md-6">
                                        <span className="profile-label">Mobile Number</span>
                                        <span className="profile-value">{Profile.mobileNumber}</span>
                                    </li>
                                    <li className="col-md-6">
                                        <span className="profile-label">Date of Birth</span>
                                        <span className="profile-value">{Profile.dob}</span>
                                    </li>
                                    <li className="col-md-6">
                                        <span className="profile-label">Qualification</span>
                                        <span className="profile-value">{Profile.qualification}</span>
                                    </li>
                                    <li className="col-md-12">
                                        <span className="profile-label">Address</span>
                                        <span className="profile-value">{Profile.address}, {Profile.city}, {Profile.country} - {Profile.zipcode}</span>
                                    </li>
                                    <li className="col-md-12">
                                        <span className="profile-label">About Yourself</span>
                                        <span className="profile-value">{Profile.bio}</span>
                                    </li>
                                    <li className="col-md-12">
                                        <span className="profile-label">Profile Picture</span>
                                        <span className="profile-value">{Profile.profilePhoto && <img src={`http://localhost:5000${Profile.profilePhoto}`} alt="Profile Photo" width="100" />}</span>
                                    </li>
                                </ul>
                                <div className='action'>
                                    <button type='button' className='btn-edit mr10' onClick={() => handleEditProfile(Profile)}>Edit</button>
                                    <button type='button' className='btn-delete' onClick={() => handleDeleteProfile(Profile.id)}>Delete</button>
                                </div>
                            </div>
                        ))}                        
                    </div>
                </div>
            </div>
           )}           
        </>
    );
}

export default Profile;
