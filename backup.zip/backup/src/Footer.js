function Footer(){
    return(
        <>
            <footer className="footer-main">Copyright &copy; 2024 by <strong>React Form</strong>. All Right Reserved</footer>
        </>
    );
}

export default Footer;