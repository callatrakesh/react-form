import React, { useState, useEffect } from 'react';

function JobApplication(){

    const [applicants, setApplicants] = useState([]);
    const [formData, setFormData] = useState({
      fname:'', 
      lname:'', 
      email:'', 
      positionFor:'', 
      availableDate:'', 
      employeeStatus:'', 
      resumeLink:'', 
      resume:null, 
      refrence:'', 
      refrenceEmail:''
    });
    const [isEditing, setIsEditing] = useState(false);
    const [isVisible, setIsVisible] = useState(false);

    const fetchApplicants = () => {
        fetch('http://localhost:5000/applications')
            .then(response => response.json())
            .then(data => setApplicants(data));  
     };
     
     useEffect(() => {
      if (applicants.length > 0) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    }, [applicants]);

    useEffect(() => {
        fetchApplicants();                     
    }, []);

    
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };
  
    const handleFileChange = (e) => {
      const file = e.target.files[0];
      const allowedFileTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']; // Allowed MIME types     
      const maxFileSize = 2 * 1024 * 1024; // 2MB size limit (in bytes)

      if (file) {
        if (!allowedFileTypes.includes(file.type)) {
          alert('Invalid file type. Only PDF or Word documents are allowed.');
          e.target.value = ''; 
          return;
        }
        if (file.size > maxFileSize) {
          alert('File size exceeds the limit of 2MB.');
          e.target.value = ''; 
          return;
        }
        setFormData({
          ...formData,
          resume: file.name, 
        });
      }      
    };
    
/*
    const handleFileChange = (e) => {
      const file = e.target.files[0];
      const allowedFileTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']; // Allowed MIME types     
      const maxFileSize = 2 * 1024 * 1024; // 2MB size limit (in bytes)
    
      if (file) {
        if (!allowedFileTypes.includes(file.type)) {
          alert('Invalid file type. Only PDF or Word documents are allowed.');
          e.target.value = ''; 
          return;
        }
        if (file.size > maxFileSize) {
          alert('File size exceeds the limit of 2MB.');
          e.target.value = ''; 
          return;
        }
        setFormData({
          ...formData,
          resume: file.name // Store the file itself, not just its name
        });
      }      
    };
    */
   
 
    const handleAddAplicant = () => {
        const newUserId = String(applicants.length + 1); // Convert ID to string
        fetch('http://localhost:5000/applications', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ...formData, id: newUserId })
        })
        .then(response => response.json())
        .then(() => {
            fetchApplicants();
            setFormData({
              fname:'', 
              lname:'', 
              email:'', 
              positionFor:'', 
              availableDate:'', 
              employeeStatus:'', 
              resumeLink:'', 
              resume:null, 
              refrence:'', 
              refrenceEmail:''
            });
        });
    };
  
 /*
    const handleAddAplicant = () => {
      const newUserId = String(applicants.length + 1); // Convert ID to string
      const formDataObj = new FormData(); 
      formDataObj.append('id', newUserId);
      formDataObj.append('fname', formData.fname);
      formDataObj.append('lname', formData.lname);
      formDataObj.append('email', formData.email);
      formDataObj.append('positionFor', formData.positionFor);
      formDataObj.append('availableDate', formData.availableDate);
      formDataObj.append('employeeStatus', formData.employeeStatus);
      formDataObj.append('resumeLink', formData.resumeLink);
      formDataObj.append('refrence', formData.refrence);
      formDataObj.append('refrenceEmail', formData.refrenceEmail);
            
      if (formData.resume) {
        formDataObj.append('resume', formData.resume.name);  
      }
  
      fetch('http://localhost:5000/applications', {
          method: 'POST',
          body: formDataObj,  // Send FormData directly
      })
      .then(response => {
        if (!response.ok) {
            throw new Error(`Server error: ${response.statusText}`);
        }
        return response.json();
    })
      .then(() => {
          fetchApplicants();
          setFormData({
            fname:'', 
            lname:'', 
            email:'', 
            positionFor:'', 
            availableDate:'', 
            employeeStatus:'', 
            resumeLink:'', 
            resume:null, 
            refrence:'', 
            refrenceEmail:''
          });
      })
      .catch(error => {
        console.error('Error:', error);
        alert(`Error submitting application: ${error.message}`);
    });
  };
*/
    const handleUpdateUser = () => {
      fetch(`http://localhost:5000/applications/${formData.id}`, {
          method: 'PUT',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
      })
          .then(response => response.json())
          .then(() => {
            fetchApplicants();
              setFormData({
                fname:'', 
                lname:'', 
                email:'', 
                positionFor:'', 
                availableDate:'', 
                employeeStatus:'', 
                resumeLink:'', 
                resume:null, 
                refrence:'', 
                refrenceEmail:''
              });
              setIsEditing(false);
          });
  };

    const handleDeleteApplicant = (id) => {
        /*
        if (users.length === 1) {
            alert("Cannot delete the last remaining user.");
            return;
        }*/
        fetch(`http://localhost:5000/applications/${id}`, {
            method: 'DELETE'
        })
            .then(() => {
                fetchApplicants();
            });
    };
    const handleEditApplicant = (applicants) => {
        setIsEditing(true);
        setFormData(applicants);
    };
   
    const handleResetForm = () => {
        setFormData({
          fname:'', 
          lname:'', 
          email:'', 
          positionFor:'', 
          availableDate:'', 
          employeeStatus:'', 
          resumeLink:'', 
          resume:null, 
          refrence:'', 
          refrenceEmail:''
        });
        setIsEditing(false);
    }; 

    return(
        <>
            <div className="panel">
                <div className="panel-header">
                  <h3 className="panel-title">{isEditing ? 'Change in Job Application' : 'Job Application'}</h3>
                </div>
                <div className="panel-body">
                  <p className="mb30">Thank you for your interest in working with us. Please check below for available job opportunities that meet your criteria and send your application by filling out the Job Application Form.</p>
                  <form>
                    <div className="form-group">
                      <label className="form-lable">Name</label>
                      <div className="form-row">
                        <div className="col-6">
                          <input type="text" className="form-control" name="fname" placeholder="First Name" value={formData.fname} onChange={handleInputChange} required/>
                        </div>
                        <div className="col-6">
                          <input type="text" className="form-control" name="lname" placeholder="Last Name" value={formData.lname} onChange={handleInputChange} />
                        </div>
                      </div>
                    </div>
                    <div className="form-group">
                      <label className="form-lable">Email ID</label>
                      <input type="email" className="form-control" placeholder="emailid@domain.in" name="email" value={formData.email} onChange={handleInputChange} required/>
                    </div>
                    <div className="row">
                      <div className="col-6 col-md-6">
                        <div className="form-group">
                          <label className="form-label">What Position are you applying for?</label>
                          <select className="form-control" name="positionFor" value={formData.positionFor} onChange={handleInputChange} required>
                            <option value="">Select</option>
                            <option value="PHP Backed Developer">PHP Backed Developer</option>
                            <option value="PHP Team Lead">PHP Team Lead</option>
                            <option value="CTO">CTO</option>
                            <option value="CEO">CEO</option>
                            <option value="IT Manager">IT Manager</option>
                            <option value="Coach">Coach</option>
                            <option value="UI Developer">UI Developer</option>
                          </select>
                        </div>                        
                      </div>
                      <div className="col-6 col-md-6">
                        <div className="form-group">
                          <label className="form-label">Available Date</label>
                          <input type="date" className="form-control" name="availableDate" value={formData.availableDate} onChange={handleInputChange}/>
                        </div>
                      </div>
                    </div>
                    <div className="form-group">
                      <label className="form-label">What is your current employee status?</label>
                      <ul className="row">
                          <li className="col-6">
                              <label><input type="radio" name="employeeStatus" value="Employed" checked={formData.employeeStatus === 'Employed'} onChange={handleInputChange} required /> Employed</label>
                          </li>
                          <li className="col-6">
                              <label><input type="radio" name="employeeStatus" value="Self-Employed" checked={formData.employeeStatus === 'Self-Employed'} onChange={handleInputChange} required/> Self-Employed</label>
                          </li>
                          <li className="col-6">
                              <label><input type="radio" name="employeeStatus" value="Unemployed" checked={formData.employeeStatus === 'Unemployed'} onChange={handleInputChange} required/> Unemployed</label>
                          </li>
                          <li className="col-6">
                              <label><input type="radio" name="employeeStatus" value="Student" checked={formData.employeeStatus === 'Student'} onChange={handleInputChange} required/> Student</label>
                          </li>
                      </ul>
                    </div>
                    <div className="row">
                      <div className="col-6 col-md-6">
                        <div className="form-group">
                          <label className="form-label">Please provide your resume link</label>
                          <input type="url" className="form-control" placeholder="www.yourresume.com" name="resumeLink" value={formData.resumeLink} onChange={handleInputChange}/>
                        </div>                        
                      </div>
                      <div className="col-6 col-md-6">
                        <div className="form-group">
                          <label className="form-label">Please Upload your resume</label>
                          <input type="file" name="resume" accept=".pdf,.doc,.docx" onChange={handleFileChange} required/>
                        </div>                        
                      </div>
                    </div>                      
                      <div className="row">
                        <div className="col-6 col-md-6">
                            <div className="form-group">
                                <label className="form-label">Do you have refrences? (Optional)</label>  
                                <input type="text" className="form-control" placeholder="Name of Refrence" name="refrence" value={formData.refrence} onChange={handleInputChange}/>
                            </div>
                        </div>
                        <div className="col-6 col-md-6">
                            <div className="form-group">
                                <label className="form-label">Reference email</label>
                                <input type="email" className="form-control" name="refrenceEmail" value={formData.refrenceEmail} onChange={handleInputChange}/>
                            </div>    
                        </div>
                      </div>
                      {isEditing ? (
                            <button type="button" className="btn btn-primary mr10" onClick={handleUpdateUser}>Change Application</button>
                        ) : (
                            <button type="button" className="btn btn-primary mr10" onClick={handleAddAplicant}>Apply Now</button>
                        )}      
                      <button type="button" className="btn btn-default" onClick={handleResetForm}>Reset</button>
                  </form>
                </div>
            </div>
            {isVisible && (
              <div className='panel'>
                    <div className='panel-header'>
                        <h3 className='panel-title'>List of Job Applicants</h3>
                    </div>
                    <div className='panel-body'>
                        <ul className='application-list'>
                            {applicants.map(applicant => (
                            <li key={applicant.id}>
                                <ul className='row'>
                                    <li className='col-6 col-md-6'><strong>Name :</strong> {applicant.fname} {applicant.lname} </li>
                                    <li className='col-6 col-md-6'><strong>Email :</strong> {applicant.email} </li>
                                    <li className='col-6 col-md-6'><strong>Position For :</strong> {applicant.positionFor}  </li>
                                    <li className='col-6 col-md-6'><strong>Available Date :</strong> {applicant.availableDate} </li>
                                    <li className='col-6 col-md-6'><strong>Employee Status :</strong> {applicant.employeeStatus} </li>
                                    <li className='col-6 col-md-6'><strong>Resume Link :</strong> {applicant.resumeLink} </li>
                                    <li className='col-6 col-md-6'><strong>Resume :</strong>   {applicant.resume ? (<a href={'upload/'+ applicant.resume} download>Download Resume</a>) : "No file uploaded"} </li>
                                    <li className='col-6 col-md-6'><strong>Refrence :</strong> {applicant.refrence} </li>
                                    <li className='col-6 col-md-6'><strong>Refrence Email :</strong> {applicant.refrenceEmail} </li>
                                </ul>
                                <div className='action'>
                                    <button type='button' className='btn-edit mr10' onClick={() => handleEditApplicant(applicant)}>Edit</button>
                                    <button type='button' className='btn-delete' onClick={() => handleDeleteApplicant(applicant.id)}>Delete</button>
                                </div>
                            </li>
                            ))}
                        </ul>
                    </div>
              </div>
            )}    
        </>
    );
}

export default JobApplication;