import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProfileList = () => {

    const [profiles, setProfiles] = useState([]);

    useEffect(() => {
        fetchProfile();
      }, []);

      const fetchProfile = async () => {
        try {
          const response = await axios.get('http://localhost:5000/profiles');
          setProfiles(response.data);
        } catch (error) {
          console.error('There was an error fetching users!', error);
        }
      };




    return(
        <>
           <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-title">Profiles List</h3>
                </div>
                <div className="panel-body">
                    {profiles.map((profile) => (
                    <div className="profile-item" key={profile.id}>
                        <ul className="row">
                            <li className="col-md-6">
                                <span className="profile-label">Name</span>
                                <span className="profile-value">{profile.name}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Email ID</span>
                                <span className="profile-value">{profile.email}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Mobile Number</span>
                                <span className="profile-value">{profile.mobileNumber}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Date Of Birth</span>
                                <span className="profile-value">{profile.dob}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Qualification</span>
                                <span className="profile-value">{profile.qulification}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Address</span>
                                <span className="profile-value">{profile.address}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">City</span>
                                <span className="profile-value">{profile.city}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">country</span>
                                <span className="profile-value">{profile.country}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Pin Code</span>
                                <span className="profile-value">{profile.zipcode}</span>
                            </li>
                            <li className="col-md-6">
                                <span className="profile-label">Profile Picture</span>
                                <span className="profile-value"></span>
                            </li>
                            <li className="col-md-12">
                                <span className="profile-label">About Your self </span>
                                <span className="profile-value">{profile.bio}</span>
                            </li>
                        </ul>
                        <button className="btn btn-sm btn-primary mr10">Edit</button>
                        <button className="btn btn-sm btn-danger">Delete</button>
                        
                    </div>
                    ))}
                </div>
            </div>
        </>
    )
}

export default ProfileList;