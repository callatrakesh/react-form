function ContactUs(){
    return(
        <>
            <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-title">Contact Us</h3>
                </div>
                <div className="panel-body">
                    <p className="lead">Let us know your questions, suggestions and concerns by filling out the contact form below.</p>
                    <div className="form-group">
                        <label className="form-label">Name</label>
                        <div className="row">
                            <div className="col-6">
                                <input type="text" className="form-control" name="fname" placeholder="First Name"/>
                            </div>
                            <div className="col-6">
                                <input type="text" className="form-control" name="lname" placeholder="Last Name"/>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-6">
                            <div className="form-group">
                                <label className="form-label">Email ID</label>
                                <input type="email" className="form-control" name="email" placeholder="abcd@abcd.in"/>
                            </div>
                        </div>
                        <div className="col-6">
                            <div className="form-group">
                                <label className="form-label">Phone Number</label>
                                <input type="tel" className="form-control" name="phone" placeholder="+91-9958505995"/>
                            </div>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Subject</label>
                        <select className="form-control" name="subject">
                            <option value="">Select Subject</option>
                            <option value="Request">Request</option>
                            <option value="Suggestion">Suggestion</option>
                            <option value="Complaint">Complaint</option>
                            <option value="Proposal">Proposal</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Message</label>
                        <textarea className="form-control" rows={5} name="message"></textarea>
                    </div>
                    <button type="button" className="btn btn-primary mr10">Send Now</button>
                    <button type="button" className="btn">Cancel</button>
                </div>
            </div>
        </>
    );
}

export default ContactUs;