import Header from "./Header";
import { BrowserRouter as Router, Routes, Route, NavLink } from "react-router-dom";
import Profile from "./Profile";
import JobApplication from "./JobApplication";
import ContactUs from "./ContactUs";
import ConsultationForm from "./ConsultationForm";
import NewsLetterSubscribe from "./NewsLatterSubscribe";
import TestimonailForm from "./TestimonailForm";

function App() {
  return (
    <>    
      <Router>
        <div className="app-container">
          <Header/>
          <div className="app-body">
            <div className="app-sidebar">
              <ul className="navbar">
                <li><NavLink to="/" activeclassname="active">Create Profile</NavLink></li>
                <li><NavLink to="/jobapplication" activeclassname="active">Job Application Form</NavLink></li>
                <li><NavLink to="/contact" activeclassname="active">Contact Us</NavLink></li>
                <li><NavLink to="/consultation" activeclassname="active">Consultation Form</NavLink></li>
                <li><NavLink to="/subscribe" activeclassname="active">Subscribe to our newsletter</NavLink></li>
                <li><NavLink to="/testimonals" activeclassname="active">Testimonial Form</NavLink></li>
              </ul>
            </div>
            <div className="app-routing">
              <Routes>
                <Route path="/" element = {<Profile/>}/>
                <Route path="/jobapplication" element = {<JobApplication/>}/>
                <Route path="/contact" element = {<ContactUs/>}/>
                <Route path="/consultation" element = {<ConsultationForm/>}/>
                <Route path="/subscribe" element = {<NewsLetterSubscribe/>}/>
                <Route path="/testimonals" element = {<TestimonailForm/>}/>
              </Routes>
            </div>
          </div>
        </div>  
      </Router>    
    </>
  );
}

export default App;
