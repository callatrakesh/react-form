function ConsultationForm(){
    return(
        <>
            <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-title">Consultation Form</h3>
                </div>
                <div className="panel-body">
                    <p className="lead">Fill in desired consultation details, date and time, so that we can schedulea meeting with you at our company headquarters.</p>
                    <form>
                        <div className="form-group">
                            <label className="form-label">Full Name</label>
                            <div className="row">
                                <div className="col-6">
                                    <input type="text" className="form-control" placeholder="First Name" name="fname"/>
                                </div>
                                <div className="col-6">
                                    <input type="text" className="form-control" placeholder="Last Name" name="lname"/>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-label">Phone Number</label>
                                    <input type="text" className="form-control" placeholder="+91-9958605995"/>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-label">Email Id</label>
                                    <input type="email" className="form-control" placeholder="emailid@domain.com"/>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-label">Organization/ Company Name</label>
                                    <input type="text" className="form-control" placeholder="ACME Ltd"/>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-label">Consultation interest</label>
                                    <select className="form-control">
                                        <option value="">Please select</option>
                                        <option value="Network solutions">Network solutions</option>
                                        <option value="Business development">Business development</option>
                                        <option value="Procurement">Procurement</option>
                                        <option value="Telephony">Telephony</option>
                                        <option value="Web design">Web design</option>
                                        <option value="Support">Support</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Additional Information/ Comments</label>
                            <textarea className="form-control" rows={5} placeholder="Write here any other useful information that can help us prepare in advance (max 2000 characters)"></textarea>
                        </div>
                        <h3 className="mb30">Desired date and time for consultation</h3>
                        <div className="row">
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-lable">From Date</label>
                                    <input type="date" className="form-control"/>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-lable">From Time</label>
                                    <input type="time" className="form-control"/>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-lable">To Date</label>
                                    <input type="date" className="form-control"/>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-lable">To Time</label>
                                    <input type="time" className="form-control"/>
                                </div>
                            </div>
                        </div>
                        <button type="button" className="btn btn-primary mr10">Book Consultation</button>
                        <button type="button" className="btn">Cancel</button>
                    </form>
                </div>
            </div>
        </>
    );
}

export default ConsultationForm;