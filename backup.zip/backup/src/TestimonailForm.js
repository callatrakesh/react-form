import { Link } from "react-router-dom"

function TestimonailForm(){
    return(
        <>
            <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-title">Testimonial Form</h3>
                </div>
                <div className="panel-body">
                    <p className="lead">The testimonial form is to be used by our customers who want to share their experience with our services</p>
                    <form>
                        <div className="form-group">
                            <label className="form-label">Name</label>
                            <div className="row">
                                <div className="col-6">
                                    <input type="text" className="form-control" name="fname" placeholder="First Name"/>
                                </div>
                                <div className="col-6">
                                    <input type="text" className="form-control" name="lname" placeholder="Last Name"/>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-label">Company Name</label>
                                    <input type="text" className="form-control" name="company" placeholder="ACME Pvt. Ltd"/>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="form-group">
                                    <label className="form-label">Email Address</label>
                                    <input type="email" className="form-control" name="email" placeholder="johan-deo@gmail.com"/>
                                </div>
                            </div>
                        </div>  
                        <div className="form-group">
                            <label className="form-label">Rate Our Services</label>
                            <div className="ratting">                                
                                <input type="radio" name="ratting" value={5} id="rattingFive"/>
                                <label for="rattingFive"><i className="fa fa-star"></i></label>
                                
                                <input type="radio" name="ratting" value={4} id="rattingFour" />
                                <label for="rattingFour"><i className="fa fa-star"></i></label>
                                
                                <input type="radio" name="ratting" value={3} id="rattingThree"/>
                                <label for="rattingThree"><i className="fa fa-star"></i></label>

                                <input type="radio" name="ratting" value={2} id="rattingTwo"/>
                                <label for="rattingTwo"><i className="fa fa-star"></i></label>
                                
                                <input type="radio" name="ratting" value={1} id="rattingOne" />
                                <label for="rattingOne"><i className="fa fa-star"></i></label>
                            </div>
                        </div> 
                        <div className="form-group">
                            <label className="form-label">What feature did you like most?</label>
                            <textarea className="form-control" rows={3}></textarea>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Please mention three other features that you liked about the product / service</label>
                            <textarea className="form-control" rows={3}></textarea>
                        </div>
                        <div className="form-group">
                            <label className="form-label">What would you improve about the product / service?</label>
                            <textarea className="form-control" rows={3}></textarea>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Would you like to add something else?</label>
                            <textarea className="form-control" rows={3}></textarea>
                        </div>
                        <div className="form-group">
                            <label><input type="checkbox" className="mr5"/> I agree to <Link to="/">Terms of Service</Link></label>
                        </div> 
                        <button type="button" className="btn btn-primary mr10">Submit</button>  
                        <button type="button" className="btn">Cancel</button>
                    </form>                    
                </div>
            </div>
        </>
    )
}

export default TestimonailForm