function Header (){
    return(
        <>
            <header className="header-main">
                <button type="button" className="header-menu" area-label="menu">
                    <span className="line"></span>
                    <span className="line"></span>
                    <span className="line"></span>
                </button> 
                Forms Examples
            </header>
        </>
    );
}

export default Header;