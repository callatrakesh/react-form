function NewsLetterSubscribe (){
    return(
        <>
            <div className="panel">
                <div className="panel-header">
                    <h3 className="panel-title">Subscribe to our newsletter</h3>
                </div>
                <div className="panel-body">
                    <p className="lead">Welcome to our Newsletter Subscription Center. Sign Up in the Newsletter form below to receive the latest news and updates from our company.</p>
                    <form>
                        <div className="form-group">
                            <label className="form-label">Email</label>
                            <input type="email" className="form-control" placeholder="johan.deo@example.com"/>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Name</label>
                            <div className="row">
                                <div className="col-6">
                                    <input type="text" className="form-control" placeholder="First Name"/>
                                </div>
                                <div className="col-6">
                                    <input type="text" className="form-control" placeholder="Last Name"/>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Areas of interest</label>
                            <div className="row">
                                <div className="col-6 mb5">
                                    <label><input type="checkbox" className="mr5"/> Product updates</label>
                                </div>
                                <div className="col-6 mb5">
                                    <label><input type="checkbox" className="mr5"/> Press releases</label>
                                </div>
                                <div className="col-6 mb5">
                                    <label><input type="checkbox" className="mr5"/> Promotions</label>
                                </div>
                                <div className="col-6 mb5">
                                    <label><input type="checkbox" className="mr5"/> Dropped product features</label>
                                </div>
                                <div className="col-6 mb5">
                                    <label><input type="checkbox" className="mr5"/> How to's</label>
                                </div>
                                <div className="col-6 mb5">
                                    <label><input type="checkbox" className="mr5"/> Scheduled downtime</label>
                                </div>
                            </div>
                        </div>
                        <button type="button" className="btn btn-primary mr10">Subscribe News Letter</button>
                        <button type="button" className="btn">Cancel</button>
                    </form>
                </div>
            </div>
        </>
    )
}

export default NewsLetterSubscribe;