const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const PORT = 5000;

// Ensure the uploads directory exists
const dir = path.join(__dirname, 'uploads');
if (!fs.existsSync(dir)){
    fs.mkdirSync(dir);
}

app.use('/uploads', express.static('uploads'));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads/')
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now()
      cb(null, uniqueSuffix + '-' + file.originalname)
    }
})


const upload = multer({ storage: storage })

let profiles = [];

// POST route to create a new profile
app.post('/profiles', upload.single('profilePhoto'), (req, res) => {
    const { name, email, mobileNumber, dob, qualification, address, city, country, zipcode, bio } = req.body;
    const newProfileId = String(profiles.length + 1);
    const profilePhoto = req.file ? `/uploads/${req.file.filename}` : null;
    const newProfile = { id: newProfileId, name, email, mobileNumber, dob, qualification, address, city, country, zipcode, bio, profilePhoto };
    profiles.push(newProfile);
    res.json(newProfile);
});

// GET route to fetch all profiles
app.get('/profiles', (req, res) => {
    res.json(profiles);
});

// Get Single User by ID (GET)
app.get('/profiles/:id', (req, res) => {
    const profile = profiles.find(u => u.id == req.params.id);
    if (profile) {
        res.json(profile);
    } else {
        res.status(404).json({ error: 'Profile not found' });
    }
});

// Same for PUT route
app.put('/profiles/:id', upload.single('profilePhoto'), (req, res) => {
    const { name, email, mobileNumber, dob, qualification, address, city, country, zipcode, bio } = req.body;
    const profilePhoto = req.file ? `/uploads/${req.file.filename}` : null; // Handle the updated photo
    const index = profiles.findIndex(u => u.id == req.params.id);
    if (index !== -1) {
        profiles[index] = { ...profiles[index], name, email, mobileNumber, dob, qualification, address, city, country, zipcode, bio, profilePhoto: profilePhoto || profiles[index].profilePhoto };
        res.json(profiles[index]);
    } else {
        res.status(404).json({ error: 'Profile not found' });
    }
});

// DELETE route to remove a profile
app.delete('/profiles/:id', (req, res) => {
    const index = profiles.findIndex(u => u.id == req.params.id);
    if (index !== -1) {
        profiles.splice(index, 1);
        res.json({ success: true });
    } else {
        res.status(404).json({ error: 'Profile not found' });
    }
});

app.listen(PORT, () => {
    console.log("Server is Successfully Running, and App is listening on port " + PORT);
});