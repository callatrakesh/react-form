const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5001;


// Ensure the 'uploads' directory exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Middleware for parsing JSON and urlencoded form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


// Set up multer for file storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); // Directory to store the files
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// API to handle job applications (with file upload)
app.post('/applications', upload.single('resume'), (req, res) => {
  try {
    const { fname, lname, email, positionFor, availableDate, employeeStatus, resumeLink, refrence, refrenceEmail } = req.body;

    console.log(req.body);  // Log the form data
    console.log(req.file); 
    
    res.json({
      success: true,
      message: 'Application received successfully',
      data: {
        fname,
        lname,
        email,
        positionFor,
        availableDate,
        employeeStatus,
        resumeLink,
        resumeFileName: req.file ? req.file.filename : null,
        refrence,
        refrenceEmail
      }
    });
  } catch (error) {
    console.error(error);  // Log the error
    res.status(500).json({ success: false, message: 'Internal Server Error', error: error.message });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
